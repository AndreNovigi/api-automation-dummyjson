# ✅ API Automation - DummyJSON

## ▶️ Como executar
mvn clean test

## 📊 Allure
mvn allure:serve

## ✅ Evidência
- Testes automatizados REST Assured
- Schema Validation
- CI com GitHub Actions

## 🐞 Bug encontrado
POST /products/add retorna 201 mesmo inválido

## 🚀 Pipeline
Executa testes automaticamente no push
